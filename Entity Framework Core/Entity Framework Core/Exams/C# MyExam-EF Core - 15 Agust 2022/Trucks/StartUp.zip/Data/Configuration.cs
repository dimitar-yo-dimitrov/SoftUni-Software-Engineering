﻿namespace Trucks.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-B9BOKON\SQLEXPRESS;Database=Trucks;Trusted_Connection=True";
    }
}