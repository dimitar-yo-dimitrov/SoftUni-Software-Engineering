﻿namespace Trucks.Data.Models.Enums
{
    public enum MakeType
    {
        Daf, Man, Mercedes, Scania, Volvo
    }
}
