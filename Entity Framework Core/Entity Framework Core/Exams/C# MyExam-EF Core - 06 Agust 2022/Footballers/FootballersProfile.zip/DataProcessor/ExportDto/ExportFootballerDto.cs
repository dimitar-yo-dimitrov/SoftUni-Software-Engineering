﻿using System;
using VaporStore.Data.Models.Enums;

namespace Footballers.DataProcessor.ExportDto
{
    public class ExportFootballerDto
    {
        public string Name { get; set; }

        public DateTime ContractStartDate { get; set; }

        public DateTime ContractEndDate { get; set; }

        public PositionType PositionType { get; set; }

        public BestSkillType BestSkillType { get; set; }

    }
}
