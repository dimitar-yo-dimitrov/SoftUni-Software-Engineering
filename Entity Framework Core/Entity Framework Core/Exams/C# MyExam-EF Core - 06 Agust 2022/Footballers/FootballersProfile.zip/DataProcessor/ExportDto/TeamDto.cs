﻿using System.Collections.Generic;

namespace Footballers.DataProcessor.ExportDto
{
    public class TeamDto
    {
        public string Name { get; set; }

        public List<ExportFootballerDto> Footballers { get; set; }
    }
}
