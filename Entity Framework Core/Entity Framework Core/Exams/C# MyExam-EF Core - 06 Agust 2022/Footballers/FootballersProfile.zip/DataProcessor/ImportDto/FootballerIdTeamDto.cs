﻿namespace Footballers.DataProcessor.ImportDto
{
    public class FootballerIdTeamDto
    {
        public int? Id { get; set; }
    }
}
