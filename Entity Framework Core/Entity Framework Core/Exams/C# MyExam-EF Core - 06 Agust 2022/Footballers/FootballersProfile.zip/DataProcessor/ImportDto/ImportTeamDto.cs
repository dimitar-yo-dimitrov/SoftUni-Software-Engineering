﻿namespace Footballers.DataProcessor.ImportDto
{
    public class ImportTeamDto
    {
        public string Name { get; set; }

        public string Nationality { get; set; }

        public int Trophies { get; set; }

        public virtual FootballerIdTeamDto[] Footballers { get; set; }
    }
}
