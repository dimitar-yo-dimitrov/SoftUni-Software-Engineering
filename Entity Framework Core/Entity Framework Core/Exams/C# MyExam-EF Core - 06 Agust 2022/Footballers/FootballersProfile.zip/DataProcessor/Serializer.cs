﻿using System.Linq;
using Artillery.DataProcessor.Helper;
using Newtonsoft.Json;

namespace Footballers.DataProcessor
{
    using System;

    using Data;

    using Formatting = Newtonsoft.Json.Formatting;

    public class Serializer
    {
        public static string ExportCoachesWithTheirFootballers(FootballersContext context)
        {
            string rootName = "Coaches";

            var coaches = context
                .Coaches
                .ToArray()
                .Where(c => c.Footballers.Any())
                .Select(c => new
                {
                    FootballersCount = c.Footballers.Count(),
                    CoachName = c.Name,
                    Footballer = c.Footballers.Select(f => new
                    {
                        Name = f.Name,
                        Position = f.PositionType,
                    }).OrderBy(f => f.Name)
                })
                .OrderByDescending(c => c.Footballer.Count())
                .ThenBy(c => c.CoachName)
                .ToArray();



            return ConvertXml.SerializeXml(coaches, rootName);

        }

        public static string ExportTeamsWithMostFootballers(FootballersContext context, DateTime date)
        {
            var teams = context.TeamsFootballers
                .ToArray()
                .Where(t => t.Footballer.Name != null)
                .Where(t => t.Footballer.ContractStartDate >= date)
                .Select(t => new
                {
                    Name = t.Team.Name,
                    Footballers = t.Footballer.TeamsFootballers.Where(f => f.Footballer.ContractStartDate >= date).Select(f => new
                    {
                        FootballerName = f.Footballer.Name,
                        ContractStartDate = f.Footballer.ContractStartDate.ToString("d"),
                        ContractEndDate = f.Footballer.ContractEndDate.ToString("d"),
                        BestSkillType = f.Footballer.BestSkillType,
                        PositionType = f.Footballer.PositionType
                    })
                        .OrderByDescending(f => f.ContractEndDate)
                        .ThenBy(f => f.FootballerName)

                })
                .Take(5)
                .OrderByDescending(t => t.Footballers.Count())
                .ThenBy(t => t.Name)
                .ToArray();

            return JsonConvert.SerializeObject(teams, Formatting.Indented);
        }
    }
}
