﻿namespace Footballers.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-B9BOKON\SQLEXPRESS;Database=Footballers;Trusted_Connection=True";
    }
}
