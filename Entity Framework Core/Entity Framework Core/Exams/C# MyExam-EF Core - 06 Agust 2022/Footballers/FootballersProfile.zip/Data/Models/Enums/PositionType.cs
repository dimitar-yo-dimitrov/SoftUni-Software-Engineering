﻿namespace VaporStore.Data.Models.Enums
{
    public enum PositionType
    {
        Goalkeeper,
        Defender,
        Midfielder,
        Forward
    }
}
